All artifacts in this distribution, except mancenter.war, are released under Apache v2 License. See apache-v2-license.txt.

For mancenter.war, see mancenter-license.txt